package com.finalbi.evenbettertestmod.items;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;

public class ItemModel extends Item {


    public ItemModel() {
        super(new Item.Properties().group(ItemGroup.MATERIALS));
    }
}
