package com.finalbi.evenbettertestmod.util;

import com.finalbi.evenbettertestmod.EvenBetterTestMod;
import com.finalbi.evenbettertestmod.items.ItemModel;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class RegistryHandler {

    public static final DeferredRegister<Item> ITEMS = new DeferredRegister<>(ForgeRegistries.ITEMS, EvenBetterTestMod.MOD_ID);

    //items
    public static final RegistryObject<Item> PINEAPPLE = ITEMS.register("pineapple", ItemModel::new);

    //Consructor/int functions

    public static void init(){ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());}
}
